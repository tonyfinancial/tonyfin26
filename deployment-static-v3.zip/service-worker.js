const CACHE = 'tony-financial-v5'
const APP_SHELL = ['/', '/portal', '/portal/login', '/instalar', '/index.html', '/manifest.webmanifest', '/icon-180.png', '/icon-192.png', '/icon-512.png', '/logo-master.png', '/qr-instalar.png']
self.addEventListener('install', event => { event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(APP_SHELL))); self.skipWaiting() })
self.addEventListener('activate', event => { event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key !== CACHE).map(key => caches.delete(key))))); self.clients.claim() })
self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET') return
  const url = new URL(event.request.url)
  if (url.origin !== self.location.origin) return
  event.respondWith(fetch(event.request).then(response => {
    if (response.ok && ['script','style','image','font'].includes(event.request.destination)) caches.open(CACHE).then(cache => cache.put(event.request, response.clone()))
    return response
  }).catch(() => caches.match(event.request).then(cached => cached || (event.request.mode === 'navigate' ? caches.match('/index.html') : undefined))))
})
